## OpenWrt路由固件，使用插件ShadowSocksR Plus+

本项目部署后，可以使用VLESS协议。

端口可以使用80或443，设置方式稍有不同。

具体设置请看图片示例。

***

在openwrt中配置:

***

使用443端口,  图示如下：
![443端口图示](/tutorial/img/openwrt-VLESS-443.png)

***

使用80端口,  图示如下：
![80端口图示](/tutorial/img/openwrt-VLESS-80.png)

***
