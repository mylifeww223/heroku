变量CADDYIndexPage用于CADDY部署完成后点击View显示的页面内容  
  
> 选择你中意的链接地址复制后作为变量CADDYIndexPage变量值，欢迎PR，一些推荐：  
  
* [欢迎使用caddy页面](https://raw.githubusercontent.com/caddyserver/dist/master/welcome/index.html)  
  
* [3DCEList元素周期表](https://github.com/wulabing/3DCEList/archive/master.zip)  

* [Spotify-Landing-Page-Redesign](https://github.com/WebDevSimplified/Spotify-Landing-Page-Redesign/archive/master.zip)  

* [dev-landing-page](https://github.com/flexdinesh/dev-landing-page/archive/master.zip)  
  
* [free-for-dev](https://github.com/ripienaar/free-for-dev/archive/master.zip)  
  
* [tailwindtoolbox-Landing-Page](https://github.com/tailwindtoolbox/Landing-Page/archive/master.zip)  

* [sandhikagalih/simple-landing-page](https://github.com/sandhikagalih/simple-landing-page/archive/master.zip)  
  
* [StartBootstrap/startbootstrap-new-age](https://github.com/StartBootstrap/startbootstrap-new-age/archive/master.zip)  

* [mikutap 一个好玩带音乐的页面](https://github.com/AYJCSGM/mikutap/archive/master.zip) [演示](https://aidn.jp/mikutap)  

* [WebGL流体模拟](https://github.com/PavelDoGreat/WebGL-Fluid-Simulation/archive/master.zip) [演示](https://paveldogreat.github.io/WebGL-Fluid-Simulation/)  
  
* [loruki-website](https://github.com/bradtraversy/loruki-website/archive/master.zip)  
  
* [bongo.cat一只音乐的猫](https://github.com/Externalizable/bongo.cat/archive/master.zip) [演示](https://bongo.cat/)  
